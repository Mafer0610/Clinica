const db = require('./db');

async function testConnection() {
    try {
        const [rows, fields] = await db.query('SELECT 1');
        console.log('Conexión exitosa:', rows);
    } catch (error) {
        console.error('Error al conectar a la base de datos:', error);
    }
}

testConnection();
